import { supabase } from '../lib/supabase'

/**
 * Test Supabase connection
 * This is a simple utility to verify your Supabase setup is working
 * 
 * Usage in App.jsx or any component:
 * 
 * useEffect(() => {
 *   testConnection()
 * }, [])
 */
export const testConnection = async () => {
  try {
    console.log('🔍 Testing Supabase connection...')
    
    // Test 1: Check if Supabase client is initialized
    if (!supabase) {
      console.error('❌ Supabase client not initialized')
      return false
    }

    // Test 2: Try to query a table (replace 'test' with your actual table name)
    // If table doesn't exist, this will fail gracefully
    const { data, error } = await supabase
      .from('test')
      .select('*')
      .limit(1)

    if (error) {
      // If table doesn't exist, that's okay - connection is still working
      if (error.code === 'PGRST116' || error.message.includes('does not exist')) {
        console.log('✅ Supabase connection working! (Table "test" not found - this is okay)')
        return true
      }
      console.error('❌ Supabase connection error:', error.message)
      return false
    }

    console.log('✅ Supabase connected! Data:', data)
    return true
  } catch (error) {
    console.error('❌ Connection test failed:', error)
    return false
  }
}

/**
 * Test connection to a specific table
 * @param {string} tableName - Name of the table to test
 * @returns {Promise<boolean>}
 */
export const testTableConnection = async (tableName = 'donations') => {
  try {
    console.log(`🔍 Testing connection to table: ${tableName}...`)
    
    const { data, error } = await supabase
      .from(tableName)
      .select('*')
      .limit(1)

    if (error) {
      console.error(`❌ Error accessing table "${tableName}":`, error.message)
      return false
    }

    console.log(`✅ Table "${tableName}" accessible!`, data)
    return true
  } catch (error) {
    console.error(`❌ Table test failed for "${tableName}":`, error)
    return false
  }
}

